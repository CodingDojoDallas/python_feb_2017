from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
	# 	'baseball_leagues': League.objects.filter(sport = 'Baseball'),
	# 	'womens_leagues': League.objects.filter(name__contains = "Womens"),
	# 	'hockey_types': League.objects.filter(name__contains = 'Hockey'),
	# 	'not_football': League.objects.exclude(sport = 'Football'),
	# 	'conferences': League.objects.filter(name__contains = 'Conference'),
	# 	'atlantic_region': League.objects.filter(name__contains = 'Atlantic'),
	# 	'dallas': Team.objects.filter(location = 'Dallas'),
	# 	'raptors': Team.objects.filter(team_name = 'Raptors'),
	# 	'city': Team.objects.filter(location__contains = 'City'),
	# 	't_name': Team.objects.filter(team_name__startswith = 'T'),
	# 	'alpha_location': Team.objects.order_by('location'),
	# 	'r_alpha_team': Team.objects.order_by('-team_name'),
	# 	'cooper': Player.objects.filter(last_name = 'Cooper'),
	# 	'joshua': Player.objects.filter(first_name = 'Joshua'),
	# 	'cooper_no_joshua': Player.objects.filter(last_name = 'Cooper').exclude(first_name = 'Joshua'),
	# 	'alex_or_wyatt': Player.objects.filter(first_name = 'Alexander')|Player.objects.filter(first_name = 'Wyatt'),
		'in_atlantic': Team.objects.filter(league__name = 'Atlantic Soccer Conference'),
		'current_Penguins': Player.objects.filter(curr_team__location = 'Boston', curr_team__team_name = 'Penguins'),
		'current_icbc': Player.objects.filter(curr_team__league__name = 'International Collegiate Baseball Conference'),
		'lopez': Player.objects.filter(last_name = 'Lopez', curr_team__league__name = 'American Conference of Amateur Football'),
		'all_football_players': Player.objects.filter(curr_team__league__sport = 'Football'),
		'sophia_teams': Team.objects.filter(curr_players__first_name = 'Sophia'),
		'sophia_leagues': League.objects.filter(teams__curr_players__first_name = 'Sophia'),
		'boo_flores': Player.objects.filter(last_name = 'Flores').exclude(curr_team__location = 'Washington', curr_team__team_name = 'Roughriders'),
		'samuel_evans': Team.objects.filter(all_players__first_name = 'Samuel', all_players__last_name = 'Evans'),
		'tiger_cats': Player.objects.filter(all_teams__location = 'Manitoba', all_teams__team_name = 'Tiger-cats'),
		'wichita_vikings':Player.objects.filter(all_teams__location = 'Wichita', all_teams__team_name = 'Vikings').exclude(curr_team__location = 'Wichita', curr_team__team_name = 'Vikings'),
		'jacob_gray': Team.objects.filter(all_players__first_name = 'Jacob', all_players__last_name = 'Gray').exlude(curr_players__first_name = 'Jacob', curr_players__last_name = 'Gray'),
		'joshua_afabp': Player.objects.filter(first_name = 'Josuha', all_teams__league__name = "Atlantic Federation of Amateur Baseball Players"),
		'more_than_twelve': Team.objects.annotate(num_players = Count('all_players')).filter(num_players__gte = 12),
		'players_team_count': Player.objects.annotate(num_teams = Count('all_teams')).order_by('num_teams'),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
